# HDT QR Payment Bot

Discord.js v14 prefix bot for VietQR dynamic QR payments, MongoDB order storage, webhook notifications, and `-qrcheck` reconciliation.

## Commands

- `-qr` — show payment instructions and configured bank account.
- `-qr <amount> <content>` — create a dynamic QR order, e.g. `-qr 99000 HDT123`.
- `-qrcheck` — check the newest pending order for the caller.
- `-qrhelp` — command help.

All commands use the `-` prefix; no slash commands are registered.

## Requirements

- Node.js 20+
- MongoDB / MongoDB Atlas
- Discord bot token, with **Message Content Intent** enabled in the Discord Developer Portal
- VietQR API account with Host-to-Client/ecommerce access, synchronized bank account, API credentials, and callback/webhook permission
- A public HTTPS endpoint for the webhook in production

## Install

1. Extract the zip.
2. Copy `.env.example` to `.env`.
3. Fill all required variables in `.env`. Never upload `.env` to GitHub or share it.
4. Install and start:

   ```bash
   npm install
   npm start
   ```

## VietQR setup notes

This starter uses the official Host-to-Client style endpoints documented by VietQR:

- Token: `/vqr/api/peripheral/ecommerce/token_generate` (Basic Auth)
- Dynamic QR: `/vqr/api/qr/generate-customer` (Bearer token)
- Check order: `/vqr/api/ecommerce-transactions/check-order` (Bearer token)

Production base URL: `https://api.vietqr.org`. For sandbox testing use `https://dev.vietqr.org` and the credentials supplied for the sandbox.

The bank account must be synchronized/authorized in your VietQR account. `BANK_CODE`, `BANK_ACCOUNT`, and `BANK_ACCOUNT_NAME` must match the synchronized account. Dynamic QR mode `VIETQR_QR_TYPE=0` requires `amount`, `orderId`, and `transType=C`.

Register the webhook URL with VietQR, and configure the callback authentication method according to your VietQR account/docs. The official callback flow documents `Authorization: Bearer <token>` using the token from VietQR's Get Token API. The bot validates that token by default. Set `VIETQR_WEBHOOK_TOKEN` only if VietQR explicitly configures a separate callback token for your account. Confirm the exact callback authentication/signature format with your VietQR account before production.

**Important:** VietQR products/accounts can return different QR response fields and transaction callback fields. `src/vietqr.js` and `src/payments.js` deliberately handle common field names, but you must compare them against the exact response schema provided for your VietQR account before going live. If the API returns a base64 data URL, adapt `renderQrAttachment()` to decode it rather than treating it as a URL.

## Security and payment integrity

- `.env` is excluded by `.gitignore`.
- The bot only marks an order paid after receiving a transaction from the authenticated webhook or API check and validating the amount, normalized transfer content, order ID, credit direction, and destination bank account where provided.
- Duplicate transaction IDs are rejected through a unique MongoDB index.
- A customer-uploaded screenshot is never accepted as proof of payment.
- Never use sandbox credentials or test callbacks for real payments.
- Run behind HTTPS/reverse proxy in production; do not expose secrets or full transaction payloads in public channels.
- Have the account owner review API permissions and bank account details before accepting real payments.

## Webhook URL

If `PUBLIC_WEBHOOK_URL` is set, it is printed at startup for reference. The URL should point to your deployed public endpoint, for example:

`https://your-domain.example/vietqr/transaction-sync`

The `WEBHOOK_PATH` must match the path registered in VietQR. Keep the bot process online and configure the reverse proxy/firewall to route that HTTPS path to `WEBHOOK_PORT`.

## Troubleshooting

- `Used disallowed intents`: enable Message Content Intent in the Discord Developer Portal.
- MongoDB connection error: check `MONGODB_URI`, Atlas network access, and database user permissions.
- VietQR 401/403: verify production vs sandbox credentials and API product permissions.
- QR not shown: inspect the exact response from the VietQR generate endpoint and map its QR field in `src/vietqr.js`.
- Webhook never arrives: verify the callback URL is public HTTPS, registered in VietQR, and uses the authentication method configured for your account.
