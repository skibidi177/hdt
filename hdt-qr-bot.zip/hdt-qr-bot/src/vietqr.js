const axios = require("axios");
const crypto = require("node:crypto");
const config = require("./config");

let cachedToken = "";
let tokenExpiresAt = 0;

function apiUrl(path) {
  return `${config.vietqr.baseUrl}${path.startsWith("/") ? path : `/${path}`}`;
}

async function getToken() {
  if (cachedToken && Date.now() < tokenExpiresAt) return cachedToken;
  const basic = Buffer.from(`${config.vietqr.username}:${config.vietqr.password}`).toString("base64");
  const response = await axios.post(apiUrl(config.vietqr.tokenPath), {}, {
    headers: { Authorization: `Basic ${basic}`, "Content-Type": "application/json" },
    timeout: 15000
  });
  const token = response.data?.access_token || response.data?.accessToken || response.data?.token;
  if (!token) throw new Error("VietQR token response did not contain access_token.");
  cachedToken = token;
  // Refresh early; if the provider returns an expiry, use it, otherwise cache for 10 minutes.
  const expiresIn = Number(response.data?.expires_in || response.data?.expiresIn || 600);
  tokenExpiresAt = Date.now() + Math.max(60, expiresIn - 60) * 1000;
  return cachedToken;
}

async function generateQr({ amount, content, orderId }) {
  const token = await getToken();
  const body = {
    bankCode: config.vietqr.bankCode,
    bankAccount: config.vietqr.bankAccount,
    userBankName: config.vietqr.bankAccountName,
    content,
    qrType: config.vietqr.qrType,
    amount: String(amount),
    orderId,
    transType: "C"
  };
  if (config.vietqr.qrType !== 0) {
    // VietQR requires terminalCode for static/semi-dynamic QR; configure this flow with your provider.
    throw new Error("This starter currently creates dynamic QR (qrType=0). Set VIETQR_QR_TYPE=0 or extend terminalCode/serviceCode as required.");
  }
  const response = await axios.post(apiUrl(config.vietqr.generatePath), body, {
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    timeout: 20000
  });
  const data = response.data;
  if (!data || data.status === "FAILED") {
    throw new Error(data?.message || "VietQR rejected the QR creation request.");
  }

  // Response fields can vary by VietQR product/account. Preserve likely QR payload/image fields.
  const qrPayload = data.qrCode || data.qrData || data.qrContent || data.qrString || data.payload || "";
  const qrImageUrl = data.qrDataURL || data.qrImageUrl || data.qrUrl || data.qrImage || "";
  return { raw: data, qrPayload: typeof qrPayload === "string" ? qrPayload : "", qrImageUrl: typeof qrImageUrl === "string" ? qrImageUrl : "" };
}

async function checkOrder(orderId) {
  const token = await getToken();
  // Official check-order API uses MD5(bankAccount + username) as checkSum.
  const checkSum = crypto.createHash("md5")
    .update(`${config.vietqr.bankAccount}${config.vietqr.username}`)
    .digest("hex");
  const response = await axios.post(apiUrl(config.vietqr.checkPath), {
    bankAccount: config.vietqr.bankAccount,
    type: "0",
    value: orderId,
    checkSum
  }, {
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
    timeout: 15000
  });
  return response.data;
}

module.exports = { getToken, generateQr, checkOrder };
