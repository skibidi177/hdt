require("dotenv").config();

function required(name) {
  const value = process.env[name]?.trim();
  if (!value) throw new Error(`Missing required environment variable: ${name}`);
  return value;
}

const config = {
  token: required("DISCORD_TOKEN"),
  prefix: process.env.PREFIX || "-",
  mongoUri: required("MONGODB_URI"),
  logChannelId: process.env.PAYMENT_LOG_CHANNEL_ID || "",
  vietqr: {
    username: required("VIETQR_USERNAME"),
    password: required("VIETQR_PASSWORD"),
    baseUrl: (process.env.VIETQR_BASE_URL || "https://api.vietqr.org").replace(/\/+$/, ""),
    tokenPath: process.env.VIETQR_TOKEN_PATH || "/vqr/api/peripheral/ecommerce/token_generate",
    generatePath: process.env.VIETQR_GENERATE_PATH || "/vqr/api/qr/generate-customer",
    checkPath: process.env.VIETQR_CHECK_PATH || "/vqr/api/ecommerce-transactions/check-order",
    bankCode: required("BANK_CODE"),
    bankAccount: required("BANK_ACCOUNT"),
    bankAccountName: required("BANK_ACCOUNT_NAME"),
    qrType: Number(process.env.VIETQR_QR_TYPE || 0),
    webhookToken: process.env.VIETQR_WEBHOOK_TOKEN || ""
  },
  webhookPort: Number(process.env.WEBHOOK_PORT || 3000),
  webhookPath: process.env.WEBHOOK_PATH || "/vietqr/transaction-sync",
  publicWebhookUrl: process.env.PUBLIC_WEBHOOK_URL || "",
  orderExpiryMinutes: Number(process.env.ORDER_EXPIRY_MINUTES || 30)
};

if (![0, 1, 3].includes(config.vietqr.qrType)) {
  throw new Error("VIETQR_QR_TYPE must be 0, 1, or 3.");
}
module.exports = config;
