const mongoose = require("mongoose");

const orderSchema = new mongoose.Schema({
  orderId: { type: String, required: true, unique: true, index: true },
  discordUserId: { type: String, required: true, index: true },
  channelId: { type: String, required: true },
  guildId: { type: String, default: null },
  amount: { type: Number, required: true, min: 1 },
  content: { type: String, required: true },
  status: { type: String, enum: ["pending", "paid", "expired", "cancelled"], default: "pending", index: true },
  qrPayload: { type: String, default: "" },
  qrImageUrl: { type: String, default: "" },
  referenceNumber: { type: String, default: "" },
  transactionId: { type: String, default: "", index: true },
  createdAt: { type: Date, default: Date.now },
  paidAt: { type: Date, default: null },
  expiresAt: { type: Date, required: true }
}, { timestamps: true });

module.exports = mongoose.model("Order", orderSchema);
