const mongoose = require("mongoose");

const transactionSchema = new mongoose.Schema({
  transactionId: { type: String, required: true, unique: true, index: true },
  referenceNumber: { type: String, default: "" },
  orderId: { type: String, default: "", index: true },
  amount: { type: Number, required: true },
  content: { type: String, required: true },
  bankAccount: { type: String, default: "" },
  transType: { type: String, default: "" },
  receivedAt: { type: Date, default: Date.now },
  raw: { type: mongoose.Schema.Types.Mixed, default: {} }
}, { timestamps: true });

module.exports = mongoose.model("Transaction", transactionSchema);
