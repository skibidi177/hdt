const Order = require("./models/Order");
const Transaction = require("./models/Transaction");
const config = require("./config");

function normalizeText(value) {
  return String(value ?? "").normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d").replace(/Đ/g, "D").toUpperCase().replace(/[^A-Z0-9 ]/g, " ").replace(/\s+/g, " ").trim();
}

function numberAmount(value) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.round(n) : NaN;
}

async function applyVerifiedTransaction(tx, source = "unknown") {
  const transactionId = String(tx.transactionid || tx.transactionId || tx.transactionID || tx.referenceNumber || tx.referencenumber || "").trim();
  const orderId = String(tx.orderId || tx.orderid || "").trim();
  const amount = numberAmount(tx.amount);
  const content = String(tx.content || "").trim();
  const transType = String(tx.transType || tx.transtype || "").toUpperCase();
  const bankAccount = String(tx.bankaccount || tx.bankAccount || "").trim();

  if (!transactionId || !orderId || !Number.isFinite(amount) || amount <= 0 || !content) {
    return { ok: false, reason: "Missing transaction fields" };
  }
  if (transType !== "C") return { ok: false, reason: "Not a credit transaction" };
  if (bankAccount && bankAccount !== config.vietqr.bankAccount) {
    return { ok: false, reason: "Bank account mismatch" };
  }

  // Idempotency: a provider transaction can only be applied once.
  const already = await Transaction.findOne({ transactionId });
  if (already) return { ok: true, duplicate: true };

  const order = await Order.findOne({ orderId });
  if (!order) return { ok: false, reason: "Unknown orderId" };
  if (order.status === "paid") return { ok: false, reason: "Order already paid" };
  if (order.status !== "pending") return { ok: false, reason: "Order is not pending" };
  if (order.expiresAt.getTime() < Date.now()) {
    order.status = "expired";
    await order.save();
    return { ok: false, reason: "Order expired" };
  }
  if (amount !== order.amount) return { ok: false, reason: "Amount mismatch" };
  if (normalizeText(content) !== normalizeText(order.content)) {
    return { ok: false, reason: "Transfer content mismatch" };
  }

  try {
    await Transaction.create({
      transactionId,
      referenceNumber: String(tx.referencenumber || tx.referenceNumber || ""),
      orderId,
      amount,
      content,
      bankAccount,
      transType,
      raw: { ...tx, receivedFrom: source }
    });
  } catch (error) {
    if (error.code === 11000) return { ok: true, duplicate: true };
    throw error;
  }

  order.status = "paid";
  order.paidAt = new Date();
  order.transactionId = transactionId;
  order.referenceNumber = String(tx.referencenumber || tx.referenceNumber || "");
  await order.save();
  return { ok: true, order, transactionId };
}

module.exports = { applyVerifiedTransaction };
