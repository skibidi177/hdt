const {
  Client, GatewayIntentBits, Partials, EmbedBuilder, AttachmentBuilder,
  PermissionsBitField
} = require("discord.js");
const express = require("express");
const QRCode = require("qrcode");
const mongoose = require("mongoose");
const crypto = require("node:crypto");
const config = require("./config");
const Order = require("./models/Order");
const { generateQr, checkOrder, getToken } = require("./vietqr");
const { applyVerifiedTransaction } = require("./payments");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.DirectMessages
  ],
  partials: [Partials.Channel]
});

const money = value => new Intl.NumberFormat("vi-VN").format(value) + " ₫";
const brandColor = 0x5865F2;

function baseEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(brandColor)
    .setTitle(title)
    .setDescription(description)
    .setFooter({ text: "HDT PAYMENT • VietQR" })
    .setTimestamp();
}

async function sendPaidNotification(order, txId) {
  const embed = new EmbedBuilder()
    .setColor(0x2ECC71)
    .setTitle("Thanh toán thành công")
    .setDescription("Giao dịch đã được đối soát với dữ liệu thanh toán.")
    .addFields(
      { name: "Mã đơn", value: `\`${order.orderId}\``, inline: true },
      { name: "Số tiền", value: money(order.amount), inline: true },
      { name: "Mã giao dịch", value: `\`${txId}\``, inline: false }
    )
    .setFooter({ text: "HDT PAYMENT • Đã xác minh" })
    .setTimestamp();
  try {
    const channel = await client.channels.fetch(order.channelId);
    if (channel?.isTextBased()) await channel.send({ content: `<@${order.discordUserId}>`, embeds: [embed] });
  } catch (e) { console.error("[PAYMENT] Cannot notify order channel:", e.message); }

  if (config.logChannelId) {
    try {
      const logChannel = await client.channels.fetch(config.logChannelId);
      if (logChannel?.isTextBased()) await logChannel.send({ embeds: [embed] });
    } catch (e) { console.error("[PAYMENT] Cannot send log:", e.message); }
  }
}

async function renderQrAttachment(order) {
  if (order.qrImageUrl && /^https:\/\/\S+/i.test(order.qrImageUrl)) return null;
  if (order.qrPayload) {
    const buffer = await QRCode.toBuffer(order.qrPayload, { errorCorrectionLevel: "M", margin: 2, width: 600 });
    return new AttachmentBuilder(buffer, { name: `vietqr-${order.orderId}.png` });
  }
  return null;
}

function paymentEmbed(order) {
  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle("HDT PAYMENT  /  THANH TOÁN QR")
    .setDescription("Quét mã QR bằng ứng dụng ngân hàng. Chuyển **đúng số tiền** và **đúng nội dung** để hệ thống tự đối soát.")
    .addFields(
      { name: "Số tiền", value: `**${money(order.amount)}**`, inline: true },
      { name: "Trạng thái", value: "🟡 Đang chờ thanh toán", inline: true },
      { name: "Mã đơn hàng", value: `\`${order.orderId}\``, inline: true },
      { name: "Ngân hàng", value: config.vietqr.bankCode, inline: true },
      { name: "Số tài khoản", value: `\`${config.vietqr.bankAccount}\``, inline: true },
      { name: "Chủ tài khoản", value: config.vietqr.bankAccountName, inline: true },
      { name: "Nội dung chuyển khoản", value: `\`${order.content}\``, inline: false },
      { name: "Hết hạn", value: `<t:${Math.floor(order.expiresAt.getTime() / 1000)}:R>`, inline: true },
      { name: "Kiểm tra", value: `Dùng \`${config.prefix}qrcheck\` để kiểm tra lại.`, inline: true }
    )
    .setFooter({ text: "Chỉ xác nhận khi VietQR xác minh được giao dịch thực tế." })
    .setTimestamp(order.createdAt);
}

async function createOrder(message, amount, rawContent) {
  if (!Number.isSafeInteger(amount) || amount < 1000 || amount > 500000000) {
    return message.reply("Số tiền không hợp lệ. Hãy nhập số nguyên từ 1.000 đến 500.000.000 VNĐ.");
  }
  const normalizedContent = String(rawContent || "").normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "").replace(/đ/g, "d").replace(/Đ/g, "D")
    .toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (normalizedContent.length < 3 || normalizedContent.length > 19) {
    return message.reply("Nội dung sau khi chuẩn hóa phải dài 3–19 ký tự, chỉ gồm chữ không dấu và số.");
  }

  const orderId = `H${Date.now().toString(36).toUpperCase()}${crypto.randomBytes(2).toString("hex").toUpperCase()}`.slice(0, 13);
  const now = new Date();
  const order = await Order.create({
    orderId,
    discordUserId: message.author.id,
    channelId: message.channel.id,
    guildId: message.guildId,
    amount,
    content: normalizedContent,
    expiresAt: new Date(now.getTime() + config.orderExpiryMinutes * 60_000)
  });

  try {
    const qr = await generateQr({ amount, content: normalizedContent, orderId });
    order.qrPayload = qr.qrPayload;
    order.qrImageUrl = qr.qrImageUrl;
    await order.save();

    const embed = paymentEmbed(order);
    const files = [];
    const attachment = await renderQrAttachment(order);
    if (attachment) {
      files.push(attachment);
      embed.setImage(`attachment://${attachment.name}`);
    } else if (order.qrImageUrl && /^https:\/\/\S+/i.test(order.qrImageUrl)) {
      embed.setImage(order.qrImageUrl);
    } else {
      embed.addFields({ name: "QR chưa hiển thị", value: "API chưa trả về trường ảnh hoặc payload QR mà bot nhận diện được. Kiểm tra response API và cấu hình theo tài liệu VietQR." });
    }
    return message.reply({ embeds: [embed], files });
  } catch (error) {
    order.status = "cancelled";
    await order.save();
    console.error("[VIETQR] Generate QR failed:", error.response?.data || error.message);
    return message.reply("Không tạo được QR từ VietQR. Đơn đã bị hủy để tránh hiểu nhầm thanh toán. Hãy kiểm tra API credentials/cấu hình và log máy chủ.");
  }
}

async function checkLatestOrder(message) {
  const order = await Order.findOne({ discordUserId: message.author.id, status: "pending" }).sort({ createdAt: -1 });
  if (!order) {
    return message.reply({ embeds: [baseEmbed("Không có đơn đang chờ", "Bạn hiện không có đơn thanh toán nào đang chờ xác nhận.")] });
  }
  if (order.expiresAt.getTime() < Date.now()) {
    order.status = "expired";
    await order.save();
    return message.reply({ embeds: [baseEmbed("Đơn đã hết hạn", `Mã đơn \`${order.orderId}\` đã hết hạn. Hãy tạo một QR mới.`).setColor(0xED4245)] });
  }

  try {
    const response = await checkOrder(order.orderId);
    const transactions = Array.isArray(response) ? response : (Array.isArray(response?.data) ? response.data : [response]);
    let applied = false;
    for (const tx of transactions) {
      const status = Number(tx.status);
      // Check API reports status=1, but still independently validate amount/content/type/orderId.
      if (status !== 1) continue;
      const result = await applyVerifiedTransaction({
        ...tx,
        orderId: tx.orderId || tx.orderid || order.orderId,
        transType: tx.transType || "C",
        transactionid: tx.transactionid || tx.transactionId || tx.referenceNumber || tx.referencenumber
      }, "check-order");
      if (result.ok && result.order) {
        await sendPaidNotification(result.order, result.transactionId);
        applied = true;
        break;
      }
      if (result.duplicate) {
        const refreshed = await Order.findOne({ orderId: order.orderId });
        if (refreshed?.status === "paid") applied = true;
      }
    }
    const refreshed = await Order.findOne({ orderId: order.orderId });
    if (applied || refreshed?.status === "paid") {
      return message.reply({ embeds: [baseEmbed("Thanh toán đã xác nhận", `Đơn \`${order.orderId}\` đã được đối soát thành công với VietQR.`).setColor(0x2ECC71)] });
    }
    return message.reply({ embeds: [baseEmbed("Chưa tìm thấy thanh toán", "VietQR chưa xác nhận giao dịch khớp với đơn này. Nếu bạn vừa chuyển tiền, hãy chờ một chút rồi thử lại.")] });
  } catch (error) {
    console.error("[VIETQR] Check order failed:", error.response?.data || error.message);
    return message.reply("Không thể kiểm tra giao dịch với VietQR lúc này. Bot chưa xác nhận thanh toán; hãy thử lại sau.");
  }
}

client.once("ready", () => {
  console.log(`[DISCORD] Logged in as ${client.user.tag}`);
  console.log(`[WEBHOOK] Listening on port ${config.webhookPort}, path ${config.webhookPath}`);
});

client.on("messageCreate", async message => {
  if (message.author.bot || !message.content.startsWith(config.prefix)) return;
  const args = message.content.slice(config.prefix.length).trim().split(/\s+/);
  const command = (args.shift() || "").toLowerCase();

  try {
    if (command === "qr") {
      if (args.length === 0) {
        const embed = baseEmbed("HDT PAYMENT • QR BANK", "Tạo QR thanh toán theo số tiền và nội dung riêng của đơn hàng.")
          .addFields(
            { name: "Cách dùng", value: `\`${config.prefix}qr 99000 HDT123\``, inline: false },
            { name: "Kiểm tra giao dịch", value: `\`${config.prefix}qrcheck\``, inline: false },
            { name: "Ngân hàng", value: config.vietqr.bankCode, inline: true },
            { name: "Chủ tài khoản", value: config.vietqr.bankAccountName, inline: true }
          )
          .setFooter({ text: "Hãy tạo QR theo từng đơn để đối soát chính xác." });
        return message.reply({ embeds: [embed] });
      }
      if (args.length < 2) return message.reply(`Cách dùng: \`${config.prefix}qr <số tiền> <nội dung>\``);
      const amount = Number(args.shift());
      const content = args.join(" ");
      return await createOrder(message, amount, content);
    }

    if (command === "qrcheck") return await checkLatestOrder(message);

    if (command === "qrhelp") {
      return message.reply({ embeds: [
        baseEmbed("Hướng dẫn HDT PAYMENT", "Các lệnh prefix hiện có:")
          .addFields(
            { name: `${config.prefix}qr`, value: "Hiện thông tin thanh toán", inline: false },
            { name: `${config.prefix}qr <số tiền> <nội dung>`, value: "Tạo đơn QR động riêng", inline: false },
            { name: `${config.prefix}qrcheck`, value: "Đối soát đơn đang chờ mới nhất", inline: false }
          )
      ] });
    }
  } catch (error) {
    console.error("[BOT] Command failed:", error);
    if (message.channel?.isTextBased()) await message.reply("Có lỗi nội bộ. Giao dịch chưa được xác nhận; vui lòng thử lại sau.");
  }
});

const app = express();
app.use(express.json({ limit: "256kb" }));

app.get("/health", (_req, res) => res.status(200).json({ ok: true }));

app.post(config.webhookPath, async (req, res) => {
  try {
    const auth = String(req.headers.authorization || "");
    // VietQR callback docs use the Bearer token issued by Get Token.
    // If the account has a separately configured callback secret, use that override instead.
    const expectedToken = config.vietqr.webhookToken || await getToken();
    if (auth !== `Bearer ${expectedToken}`) {
      return res.status(401).json({ ok: false, error: "Unauthorized" });
    }
    const tx = req.body || {};
    const result = await applyVerifiedTransaction(tx, "webhook");
    if (result.ok && result.order) {
      await sendPaidNotification(result.order, result.transactionId);
      return res.status(200).json({ ok: true, paid: true });
    }
    if (result.ok && result.duplicate) return res.status(200).json({ ok: true, duplicate: true });
    // Return 200 to avoid retry storms for validly received but unmatched events; log for review.
    console.warn("[WEBHOOK] Unmatched transaction:", result.reason, {
      orderId: tx.orderId, amount: tx.amount, transactionid: tx.transactionid
    });
    return res.status(200).json({ ok: false, ignored: true, reason: result.reason });
  } catch (error) {
    console.error("[WEBHOOK] Processing error:", error);
    return res.status(500).json({ ok: false, error: "Processing failed" });
  }
});

async function main() {
  await mongoose.connect(config.mongoUri);
  console.log("[DATABASE] Connected to MongoDB");
  app.listen(config.webhookPort, "0.0.0.0", () => {
    console.log(`[WEBHOOK] Server listening on :${config.webhookPort}`);
    if (config.publicWebhookUrl) console.log(`[WEBHOOK] Configure VietQR callback URL: ${config.publicWebhookUrl}`);
  });
  await client.login(config.token);
}

main().catch(error => {
  console.error("[FATAL]", error);
  process.exit(1);
});
